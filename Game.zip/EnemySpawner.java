import java.util.Random;

public class EnemySpawner {
    private int frequency;
    private int counter;
    Model model;

    public EnemySpawner(Model m) {
        model = m;
        counter = 1;
        frequency = 100;
    }

    public void spawn() {
        Random random = new Random();
        if(counter % frequency == 0) {
            model.addEnemy(random.nextInt(600) + 100, 150);
            
            counter = 1;
            if (frequency >= 25) {
                frequency--;
            }
        }
        counter++;
    }

    public void setFrequency(int num) {
        frequency = num;
    }

	public int getFrequency() {
		return frequency;
	}

}
