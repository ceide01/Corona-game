import java.awt.Graphics;
import java.util.Random;

public class Enemy extends Sprite{
	private int xRatio;
	private int yRatio;
	private int xRatioModifier;
    private int yRatioModifier;
    private boolean killed;
    private boolean collision;
    private boolean hit;
    public int points;

	public Enemy() {
		super("virus.png");
		xRatioModifier = 1;
        yRatioModifier = 1;
        collision = false;
        hit = false;
        killed = false;

		Random random = new Random();
		xRatio = (random.nextInt(10) - 5);
        yRatio = (random.nextInt(10) - 5);
        points = 1;
    }

	public void updateState() {
		if(super.getX() <= 0 || super.getX()+60 >= 800) {
			xRatioModifier = -1 * xRatioModifier;
		}
		if(super.getY() <= 0 || super.getY()+60 >= 600) {
			yRatioModifier = -1 * yRatioModifier;
        }
        if(super.getX() <= 20) { //Fixes border bug
            if(xRatio < 0) {
                xRatioModifier = -1;
            } else {
                xRatioModifier = 1;
            }
            
        }
        if(super.getY() <= 80) { //Fixes border bug
            if(yRatio < 0) {
                yRatioModifier = -1;
            } else {
                yRatioModifier = 1;
            }
            
        }
		move(5, xRatio * xRatioModifier, yRatio * yRatioModifier);
	}

	public void updateImage(Graphics g) {
		super.updateImage(g);
    }
    
    public void move(int distance, double xRatio, double yRatio) {
        double traveled = distance;
		double xVal, yVal;
		
		if(xRatio == 0 && yRatio == 0) {
			xVal = 0;
			yVal = 0;
		} else {
			xVal = (traveled * xRatio) / (Math.sqrt(Math.pow(xRatio, 2) + Math.pow(yRatio, 2))); // value used in calculating final position
			yVal = (traveled * yRatio) / (Math.sqrt(Math.pow(xRatio, 2) + Math.pow(yRatio, 2))); // value used in calculating final position
		}
		// Move enemy
		super.setX((int) (super.getX() + xVal));
		super.setY((int) (super.getY() + yVal));
    }

    public void kill() {
		if(!killed) {
			super.setImage("blank.png");
			xRatio = 0;
			yRatio = 0;
			killed = true;
		}
    }
    
    public boolean canDamage() {
        if(killed) {
            return false;
        }
        if(collision && hit) {
            hit = false;
            return true;
        }
        if(collision && !hit) {
            return false;
        }
        return false;
    }

    public void collide() {
        if(collision == false) {
            collision = true;
            hit = true;
        } else {
            collision = true;
            hit = false;
        }
    }

    public void uncollide() {
        collision = false;
    }

    public int getPoints() {
        if(!killed) {
            return points;
        } else {
            return 0;
        }  
    }

    public boolean isDead() {
        return killed;
    }
}
