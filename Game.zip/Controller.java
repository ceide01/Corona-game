import java.awt.Graphics;
import java.io.IOException;
import java.awt.event.MouseListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;

class Controller implements MouseListener, KeyListener
{
    Model model;
    View view;
    private static Boolean needReload = false;
    private Thread thread;

    Controller() throws IOException, Exception {
        model = new Model(this);
        view = new View(this, model);
        thread = new Thread(new SpriteMover(this, model, view));
        thread.start();
    }

    public void update(Graphics g) {
        model.update(g);
    }

    public void mousePressed(MouseEvent e) {
        view.repaint();
    }

    public void mouseReleased(MouseEvent e) {    }
    public void mouseEntered(MouseEvent e) {    }
    public void mouseExited(MouseEvent e) {    }
    public void mouseClicked(MouseEvent e) {    }

    public static void main(String[] args) throws Exception {
        new Controller();
    }

	@Override
	public void keyTyped(KeyEvent e) {
        if (e.getKeyChar() == ' ') {
            if(!needReload) {
                model.shoot();
                needReload = true;
            }
            
        }
        if(e.getKeyChar() == 'z') {
            startThread();
		}
        view.repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
		if(keyCode == KeyEvent.VK_W) {
            model.movePlayer("up");
        }
        if(keyCode == KeyEvent.VK_A) {
            model.movePlayer("left");
        }
        if(keyCode == KeyEvent.VK_S) {
            model.movePlayer("down");
        }
        if(keyCode == KeyEvent.VK_D) {
            model.movePlayer("right");
        }
        view.repaint();
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyChar() == ' ') {
            needReload = false;
        }
    }
    
    public void startThread() {
        if(!thread.isAlive()) {
            thread = new Thread(new SpriteMover(this, model, view));
            thread.start();
        }
    }

    public Thread getThread() {
        return thread;
    }

    public void showGameOver() {
        view.showGameOver();
    }
}
