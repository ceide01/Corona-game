public class SpriteMover implements Runnable{
	Controller controller;
	Model model;
	View view;

	public SpriteMover(Controller c, Model m, View v) {
		model = m;
		view = v;
	}
	
	@Override
	public void run() {
		while (!model.isPaused()) {
			model.updateScene();
	
			view.repaint();
			
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {}
		}
	}
}
