import javax.swing.*;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.IOException;

public class View extends JFrame implements ActionListener {
    JMenuBar mb;
    JMenu menu;
    JMenuItem pause, save, load, help, exit;
    JTextArea instructions;
    Model model;
    Controller controller;


    private class MyPanel extends JPanel {
        Controller controller;

        MyPanel(Controller c) {
            controller = c;
            addMouseListener(c);
        }

        public void paintComponent(Graphics g) {
            controller.update(g);
            revalidate();
        }
    }


    public View(Controller c, Model m) throws Exception{
        controller = c;
        model = m;
        setTitle("CoronArena");
        setSize(800, 644);
        getContentPane().add(new MyPanel(c));

        //Create Menubar
        mb = new JMenuBar();
        menu = new JMenu("Menu");
        pause = new JMenuItem("Pause/Unpause");
        pause.addActionListener(this);
        save = new JMenuItem("Save Game");
        save.addActionListener(this);
        load = new JMenuItem("Load Game");
        load.addActionListener(this);
        help = new JMenuItem("Instructions and Controls");
        help.addActionListener(this);
        exit = new JMenuItem("Exit Game");
        exit.addActionListener(this);
        menu.add(pause);
        menu.add(save);
        menu.add(load);
        menu.add(help);
        menu.add(exit);
        mb.add(menu);

        setJMenuBar(mb);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        addKeyListener(c);
    }

    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        if(s == "Pause/Unpause") {
            model.togglePause();
            if(!model.isPaused()) {
                controller.startThread();
            }
        } else if(s == "Save Game") {
            try {
                File save = new File("save.txt");
                if (save.createNewFile()) {
                  System.out.println("File created: " + save.getName());
                } else {
                  System.out.println("File already exists.");
                }
              } catch (IOException ex) {
                System.out.println("An error occurred.");
                ex.printStackTrace();
              }

              String data = model.getHealth() + "\n" + model.getScore() + "\n" + model.getFrequency() + "\n" + model.getSpritesListString();

              try {
                FileWriter myWriter = new FileWriter("save.txt");
                myWriter.write(data);
                myWriter.close();
                System.out.println("Successfully wrote to the file.");
              } catch (IOException ex) {
                System.out.println("An error occurred.");
                ex.printStackTrace();
              }

        } else if(s == "Load Game") {
            model.reset();
            ArrayList<String> load = new ArrayList<String>();
            try {
                File save = new File("save.txt");
                Scanner myReader = new Scanner(save);
                while (myReader.hasNextLine()) {
                  String data = myReader.nextLine();
                  load.add(data);
                }
                myReader.close();
              } catch (FileNotFoundException ex) {
                System.out.println("An error occurred.");
                ex.printStackTrace();
              }

              model.setHealth(Integer.parseInt(load.get(0)));
              load.remove(0);
              model.setScore(Integer.parseInt(load.get(0)));
              load.remove(0);
              model.setFrequency(Integer.parseInt(load.get(0)));
              load.remove(0);

              for(String sprite: load) {
                model.addSprite(sprite);
              }


            
        } else if(s == "Instructions and Controls") {
            instructions = new JTextArea();
            try {
                BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream("instructions.txt")));
                instructions.read(input, "READING FILE :-)");
              } catch (Exception ex) {
                ex.printStackTrace();
              }
            getContentPane().add(instructions);
            repaint();

        } else if(s == "Exit Game") {
            this.dispose();
        }
    }

    public void showGameOver() {
        JOptionPane.showMessageDialog(this, "GAME OVER: Your final score was " + model.getScore() + " kills.");
    }
}

