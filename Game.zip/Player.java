public class Player extends Sprite {
    private boolean dead;
    private Model model;
	
	public Player(Model m) {
        super("Player.png");
        super.setX(200);
        super.setY(400);
        model = m;
        dead = false;
    }

    public Player(Model m, int x, int y) {
        super("Player.png");
        super.setX(x);
        super.setY(y);
        model = m;
        dead = false;
	}
	
	public void move(String direction) {
        if(!dead && !model.isPaused()) {
            if (direction == "up" && super.getY()-8 >= 64) {
                super.setY(super.getY() - 10);
                super.setImage("PlayerUp.png");
            }
            if (direction == "down" && super.getY()+32 <= 500) {
                super.setY(super.getY() + 10);
                super.setImage("PlayerDown.png");
            }
            if (direction == "left" && super.getX()-8 >= 32) {
                super.setX(super.getX() - 10);
                super.setImage("PlayerLeft.png");
            }
            if (direction == "right" && super.getX()+55 <= 700) {
                super.setX(super.getX() + 10);
                super.setImage("Player.png");
            }
        }
    }

    public void updateState() {
        if(dead) {
            super.setImage("DeadPlayer.png");
        }
    }

    public void kill() {
        dead = true;
    }

    public boolean isAlive() {
        return !dead;
    }
}
