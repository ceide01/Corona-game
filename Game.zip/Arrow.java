public class Arrow extends Sprite {
    private String direction;
    private boolean outOfBounds;
    private boolean hit;

    public Arrow() {
        super("shot_right.png");
        direction = "right";
    }

    public Arrow(String d, int x, int y) {
        super(d);
        if(d == "shot_right.png") {
            direction = "right";
            super.setX(x+30);
            super.setY(y+30);
        }
        if (d == "shot_left.png") {
            direction = "left";
            super.setX(x);
            super.setY(y+30);
        }
        if (d == "shot_up.png") {
            direction = "up";
            super.setX(x+15);
            super.setY(y);
        }
        if (d == "shot_down.png") {
            direction = "down";
            super.setX(x+15);
            super.setY(y+60);
        }
        hit = false;
        outOfBounds = false;
    }

    public void updateState() {
        //Move
        if (direction == "right") {
            super.setX(super.getX()+10);
        }
        if (direction == "left") {
            super.setX(super.getX()-10);
        }
        if (direction == "up") {
            super.setY(super.getY()-10);
        }
        if (direction == "down") {
            super.setY(super.getY()+10);
        }

        //Check if gone
        if(super.getX() < 5 || super.getX() > 790 || super.getY() < 20 || super.getY() > 590) {
			if(!outOfBounds) {
                super.setImage("blank.png");
				outOfBounds = true;
			}
        }
    }

    public boolean shot(Enemy e) {
        boolean collision = (locationX >= e.getX()+10 && locationX <= e.getX()+50 && locationY >= e.getY() && locationY <= e.getY()+50);
		if(collision && !e.isDead() && !hit) {
            super.setImage("blank.png");
            hit = true;
            return true;
		}
		return false;
    }

    public boolean toBeRemoved() {
        if(hit || outOfBounds) {
			return true;
		}
		return false;
    }
}