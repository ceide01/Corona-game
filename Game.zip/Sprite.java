import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;


class Sprite
{
	protected int locationX;
	protected int locationY;
	private Image image;
	private String description;
	private String imageName;

	public Sprite(String i)
	{
		imageName = i;
		setImage(imageName);
		description = "";
		if(imageName == "shot_up.png" || imageName == "shot_down.png") {
			description = "arrow_down";
		}
		if(imageName == "shot_left.png" || imageName == "shot_right.png") {
			description = "arrow_side";
		}
		if (imageName == "full.png" || imageName == "1damage.png" || imageName == "2damage.png" || imageName == "empty.png") {
			description = "healthbar";
		}
		locationX = 0;
		locationY = 0;
	}
	
	public int getX() {	return locationX; }
	public int getY() {	return locationY; }
	public void setX(int x) { locationX = x; }
	public void setY(int y) { locationY = y; }
	
	public void setImage(String imagePath) {
        try {
            image = ImageIO.read(new File(imagePath));
        } catch (IOException ioe) {
            System.out.println("Unable to load image file.");
        }
	}
	public Image getImage() { return image; }	
	
	public void updateImage(Graphics g) {
		if(description == "arrow_down") {
			g.drawImage(getImage(), getX(), getY(), 10, 20, null);
		} else if(description == "arrow_side") {
			g.drawImage(getImage(), getX(), getY(), 20, 10, null);
		} else if(description == "healthbar") {
			g.drawImage(getImage(), getX(), getY(), 150, 60, null);
		} else {
			g.drawImage(getImage(), getX(), getY(), 60, 60, null);
		}
	}
	
	public void updateState() {
		
	}
	
	public boolean overlaps(Sprite s) {
		boolean corner1 = (locationX >= s.getX() && locationX <= s.getX()+45 && locationY >= s.getY() && locationY <= s.getY()+45);
		boolean corner2 = (locationX+30 >= s.getX() && locationX+30 <= s.getX()+45 && locationY >= s.getY() && locationY <= s.getY()+45);
		boolean corner3 = (locationX >= s.getX() && locationX <= s.getX()+45 && locationY+30 >= s.getY() && locationY+30 <= s.getY()+45);
		boolean corner4 = (locationX+30 >= s.getX() && locationX+30 <= s.getX()+45 && locationY+30 >= s.getY() && locationY+30 <= s.getY()+45);
		if(corner1 || corner2 || corner3 || corner4) {
			return true;
		}
		return false;
	}

	public String getImageName() {
		return imageName;
	}
}