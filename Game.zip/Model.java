import java.awt.Graphics;
// import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;

class Model {
    private Image background = ImageIO.read(new File("map1.png"));
    private ArrayList<Sprite> sprites;
    private Player player;
    private Enemy enemy;
    private HealthBar healthbar;
    private String playerDirection;
    private boolean paused;
    private EnemySpawner spawner;
    private int points;
    private int bodies;
    private Controller controller;
    private String shotImage;
    private boolean gameOverDisplay;
    private int health;

    Model(Controller c) throws IOException {
        controller = c;
        sprites = new ArrayList<Sprite>();
        player = new Player(this);
        healthbar = new HealthBar();
        playerDirection = "right";
        sprites.add(player);
        sprites.add(healthbar);
        spawner = new EnemySpawner(this);
        gameOverDisplay = false;
    }

    public void update(Graphics g) {
        g.drawImage(background, 0, 0, 800, 600, null);
        for (Sprite s : sprites) {
            s.updateImage(g);
        }
    }

    public void updateScene() {
        if (!paused) {
            synchronized (sprites) {
                spawner.spawn();
                if (healthbar.getHealth() <= 0) {
                    player.kill();
                }
                Iterator<Sprite> iter = sprites.iterator();
                while (iter.hasNext()) {
                    Sprite s = iter.next();
                    s.updateState();
                    if (s instanceof Arrow) {
                        for (Sprite r : sprites) {
                            if (r instanceof Enemy && ((Arrow) s).shot(((Enemy) r))) {
                                points += ((Enemy) r).getPoints();
                                ((Enemy) r).kill();
                                bodies++;
                            }
                        }
                    }
                    if (s instanceof Player) {
                        for (Sprite r : sprites) {
                            if (r instanceof Enemy) {
                                if (((Player) s).overlaps(r)) {
                                    ((Enemy) r).collide();
                                    if (((Enemy) r).canDamage()) {
                                        healthbar.damage(1);
                                    }
                                } else {
                                    ((Enemy) r).uncollide();
                                }
                            }
                        }
                    }
                    if (s instanceof Arrow) {
                        if (((Arrow) s).toBeRemoved()) {
                            iter.remove();
                        }
                    }
                    if (s instanceof Enemy) {
                        if ((((Enemy) s)).isDead() && bodies > 10) {
                            iter.remove();
                            bodies--;
                        }
                    }
                }
            }
        }
        if (!player.isAlive()) {
            if (!gameOverDisplay) {
                gameOverDisplay = true;
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {}
                controller.showGameOver();
            }
        }
    }

    public void movePlayer(String direction) {
        player.move(direction);
        if(direction == "right") {
            shotImage = "shot_right.png";
        } else if(direction == "left") {
            shotImage = "shot_left.png";
        } if(direction == "up") {
            shotImage = "shot_up.png";
        } else if(direction == "down") {
            shotImage = "shot_down.png";
        }
    }

    public String getDirection() {
        return playerDirection;
    }

    public int getPlayerX() {
        return player.getX();
    }

    public int getPlayerY() {
        return player.getY();
    }

    public void shoot() {
        if(player.isAlive()) {
            Arrow arrow = new Arrow(shotImage, getPlayerX(), getPlayerY());
            sprites.add(arrow);
        } 
    }

    public void loadArrow(String image, int x, int y) {
        Arrow arrow = new Arrow(image, x, y);
        sprites.add(arrow);
    }

    public void addEnemy(int x, int y) {
        enemy = new Enemy();
        enemy.setX(x);
        enemy.setY(y);
        sprites.add(enemy);
    }

    public boolean isPaused() {
        return paused;
    }

    public void togglePause() {
        paused = !paused;
        if(!paused) {
            controller.startThread();
        }
    }

    public int getScore() {
        return points;
    }

    public String getSpritesListString() {
        String str = "";
        for(Sprite s: sprites) {
            int x = s.getX();
            int y = s.getY();
            String temp = s.getImageName() + ", " + x + ", " + y + "\n";
            str += temp;
        }
        return str;
    }

    public int getHealth() {
        return healthbar.getHealth();
    }

    public void setScore(int num) {
        points = num;
    }

    public void setHealth(int num) {
        health = num;
    }

	public void addSprite(String sprite) {
        String[] strings = sprite.split(", ");
        String name;
        int x, y;
        name = strings[0];
        x = Integer.parseInt(strings[1]);
        y = Integer.parseInt(strings[2]);
        if(name.equals("Player.png")) {
            player = new Player(this, x, y);
            sprites.add(player);
        } else if(name.equals("full.png") || name.contains("damage.png") || name.equals("empty.png")) {
            healthbar = new HealthBar(health);
            sprites.add(healthbar);
        } else if(name.contains("shot")) {
            loadArrow(name, x, y);
        } else if(name.equals("virus.png")) {
            addEnemy(x, y);
        }
	}

	public void reset() {
        sprites.clear();
    }
    
    public void setFrequency(int num) {
        spawner.setFrequency(num);
    }

	public int getFrequency() {
		return spawner.getFrequency();
	}
}
