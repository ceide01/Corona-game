public class HealthBar extends Sprite{
    private int health;

    public HealthBar() {
        super("full.png");
        health = 3;
    }

    public HealthBar(int num) {
        super("full.png");
        health = num;
    }

    public void updateState() {
		if(health == 3) {
            super.setImage("full.png");
        } else if(health == 2) {
            super.setImage("1damage.png");
        } else if(health == 1) {
            super.setImage("2damage.png");
        } else if(health == 0) {
            super.setImage("empty.png");
        }
    }
    
    public void damage(int num) {
        health = health - 1;
    }

    public int getHealth() {
        return health;
    }

	public void setHealth(int num) {
        health = num;
	}
}